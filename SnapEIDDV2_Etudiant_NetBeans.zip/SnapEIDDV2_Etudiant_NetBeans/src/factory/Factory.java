/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package factory;

import modele.CardPlusDeux;
import java.util.Collections;
import java.util.LinkedList;
import modele.AbstractCard;
import modele.Card;
import modele.CardDestroyPlusDeux;
import modele.CardPlusUnAdv;
import modele.CardPlusCard;
import modele.CardPlusUn;
/**
 *
 * @author douni
 */
public final class Factory {
    public Factory(){};
//	/**
//	 * Une méthode générant un deck de 30 cartes de bases. 
//	 * A decommenter une fois que vous avez une implémentation  AbstractCard avec un constructeur qui va bien
//	 */
//	
	public static LinkedList<AbstractCard> deckBase() {
		LinkedList<AbstractCard> deckBase = new LinkedList<>();
		deckBase.add(new Card(1, 1,"Hulk",""));
		deckBase.add(new CardPlusDeux(1, 1,"Odin","Revele"));
		deckBase.add(new CardPlusCard(1, 1,"Vision","Revele"));
		deckBase.add(new CardDestroyPlusDeux(2, 2,"Black Panther","Revele"));
		deckBase.add(new CardPlusUnAdv(2, 2,"Thanos","Continu"));
		deckBase.add(new CardPlusUn(3, 3,"The Punisher","Continu"));
		deckBase.add(new CardPlusDeux(3, 3,"Hawkeye","Revele"));
		deckBase.add(new Card(3, 3,"Medusa",""));
		deckBase.add(new CardPlusCard(3, 3,"The Thing","Revele"));
		deckBase.add(new CardDestroyPlusDeux(3, 3,"Gamora","Revele"));
		deckBase.add(new CardPlusUnAdv(4, 4,"Jessica Jones","Continu"));
		deckBase.add(new CardPlusUn(4, 4,"Morbius","Continu"));
		deckBase.add(new Card(5, 5,"Valkyrie",""));
		deckBase.add(new CardPlusDeux(5, 5,"Wolverine","Revele"));
		deckBase.add(new Card(6, 6,"Doctor Strange",""));
		deckBase.add(new Card(6, 6,"Venom",""));
		Collections.shuffle(deckBase);
                return deckBase;
	}
    
}

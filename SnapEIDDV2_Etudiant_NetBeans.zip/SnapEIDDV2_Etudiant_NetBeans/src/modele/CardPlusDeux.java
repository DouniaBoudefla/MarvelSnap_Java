/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

import static modele.Position.MIDDLE;

/**
 *
 * @author douni
 */
public class CardPlusDeux extends Card {   //  Si cette carte est à l'emplacement du milieu, score +2.
    
    public CardPlusDeux(int val, int cout, String nom, String effet) {
        super(val, cout, nom,effet);
    }
    
    @Override
    public void effetRevele(AbstractGame g){
        for(AbstractCard c : g.getPlay(0)){
            if(c.getPosition() == MIDDLE){
                g.setScore(0, MIDDLE, 2);
                System.out.println("UNE CARTE +2 A ETE JOUE PAR LE JOUEUR "+g.getName(0)+"\n");
            }
        }
        for(AbstractCard c: g.getPlay(1)){
            if(c.getPosition() == MIDDLE){
                g.setScore(1, MIDDLE, 2);
                System.out.println("UNE CARTE +2 A ETE JOUE PAR LE JOUEUR "+g.getName(1)+"\n");
            }
        }
    }
    
}

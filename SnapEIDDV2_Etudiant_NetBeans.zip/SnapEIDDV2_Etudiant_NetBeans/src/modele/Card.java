/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author douni
 */
public class Card extends AbstractCard{
    
    private String nom;
    private int valeur;
    private int cout;
    private Position position;
    private String effet;
   
    
    public Card(int val,int cout,String nom,String effet){
        this.cout=cout;
        this.valeur=val;
        this.nom=nom;
        this.effet=effet;
    }

    
    @Override
    public String getNom() {
        return this.nom;
    }
    
    @Override
    public String getEffet(){
        return this.effet;
    }

   
    @Override
    public int getValeur() {
        return this.valeur;
    }
    

    @Override
    public int getCout() {
        return this.cout;
    }

    @Override
    public String getDescription() {
        return "Carte: "+this.nom+" Valeur: "+this.valeur+" Cout: "+this.cout;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void setPosition(Position p) {
        this.position=p;
    }
    
   @Override
    public String toString(){
        return "Carte: "+this.getNom()+" Valeur: "+this.getValeur()+" Cout: "+this.getCout();
        
    }

   

    
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

import factory.Factory;
import java.util.LinkedList;
import static modele.Position.LEFT;
import static modele.Position.MIDDLE;
import static modele.Position.RIGHT;

/**
 *
 * @author douni
 */
public class Game extends AbstractGame{
    
    public LinkedList<AbstractCard>[] mains=new LinkedList[2];
    public LinkedList<AbstractCard>[] decks=new LinkedList[2];
    public LinkedList<AbstractCard>[][] emplacement=new LinkedList[2][3];
    public LinkedList<AbstractCard>[][] cout_prep=new LinkedList[2][3];  
    public String[] nomJoueurs=new String[2];
    public int[][] score=new int[2][3];
    public int[] energy=new int[2];
    public int turn;
    
    public Game(){
        for(int i=0;i<2;i++){
            this.mains[i]=new LinkedList();
            this.decks[i]=new LinkedList();
        }
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                this.emplacement[i][j]=new LinkedList();
                this.cout_prep[i][j]=new LinkedList();
            }
        }
        
    }

    @Override
    public String getName(int side) {
        return this.nomJoueurs[side];
    }

    @Override
    public void setName(int side, String name) {
       this.nomJoueurs[side]=name;
    }

    @Override
    public LinkedList<AbstractCard> getDeck(int side) {
        return this.decks[side];
    }

    @Override
    public void setDeck(int side, LinkedList<AbstractCard> deck) {
       this.decks[side]=deck;
    }

    @Override
    public LinkedList<AbstractCard> getBoard(int side) {
        LinkedList<AbstractCard> p=new LinkedList();
        for(int i=0;i<3;i++){
            p.addAll(this.emplacement[side][i]);
        }
        return p;
    }

    @Override
    public LinkedList<AbstractCard> getBoard(int side, Position p) {
        switch(p){
            case LEFT :
               // System.out.println("EMPLACEMENT 0");
                return this.emplacement[side][0];
            case MIDDLE  :
               // System.out.println("EMPLACEMENT 1");
                return this.emplacement[side][1];
            case RIGHT  :
               // System.out.println("EMPLACEMENT 2");
                return this.emplacement[side][2];
        }
        return null;
    }

    @Override
    public LinkedList<AbstractCard> getHand(int side) {
        return this.mains[side];
        
    }

    @Override
    public void setScore(int side, Position pos, int score) {
        if(pos == LEFT){
            this.score[side][0]=this.score[side][0]+score;
        }
        else if(pos == MIDDLE){
            this.score[side][1]=this.score[side][1]+score;
        }
        else if(pos == RIGHT){
            this.score[side][2]=this.score[side][2]+score;
        }
    } 
    
    @Override
    public void setScore2(int side, Position pos, int score){
        if(pos == LEFT){
            System.out.println(this.getScore(side,pos)+""+pos);
            this.score[side][0]+=this.getScore(side, pos)*score;
            System.out.println(this.score[side][0]+""+pos);
        }
        else if(pos == MIDDLE){
            System.out.println(this.score[side][1]+""+pos);
            this.score[side][1]+=this.getScore(side,pos)*score;
            System.out.println(this.score[side][1]+""+pos);
        }
        else if(pos == RIGHT){
            System.out.println(this.score[side][2]+""+pos);
            this.score[side][2]+=this.getScore(side,pos)*score;
            System.out.println(this.score[side][2]+""+pos);
        }
    }
    
    @Override
    public int getScore(int side, Position pos) {
        int score=0;
        if(pos == LEFT){
            score=this.score[side][0];
            for(AbstractCard c: this.emplacement[side][0]){
                score = score+c.getValeur();
            }
            return score;
        }
        else if(pos == MIDDLE){
            score=this.score[side][1];
            for(AbstractCard c: this.emplacement[side][1]){
                score = score+c.getValeur();
            }
            return score;
        }
        else if(pos == RIGHT){
            score=this.score[side][2];
            for(AbstractCard c: this.emplacement[side][2]){
                score = score+c.getValeur();
            }
            return score;
        }
        return score;
    }

    @Override
    public int getEnergy(int side) {
        return this.energy[side];
    }

    @Override
    public int getTurn() {
        return turn;
    }

    @Override
    public LinkedList<AbstractCard> getPlay(int side) {
        LinkedList<AbstractCard> p=new LinkedList();
        for(AbstractCard c:this.cout_prep[side][0]){
            p.add(c);
        }
        for(AbstractCard c:this.cout_prep[side][1]){
            p.add(c);
        }
        for(AbstractCard c:this.cout_prep[side][2]){
            p.add(c);
        }
       // System.out.println("getPlay(): "+p);
        return p;
    }

    @Override
    public LinkedList<AbstractCard> getPlay(int side, Position pos) {
        switch(pos){
            case LEFT :
                return this.cout_prep[side][0];       
            case MIDDLE :
               return this.cout_prep[side][1];
            case RIGHT :
               return this.cout_prep[side][2];   
        }
        return null;
    }

    @Override
    public void setBoard(int side, LinkedList<AbstractCard> myPlay) {
        for(AbstractCard c:myPlay){
            if(c.getPosition() == LEFT){
                this.emplacement[side][0].add(c);
            }
            else if(c.getPosition() == MIDDLE){
                this.emplacement[side][1].add(c);
            }
            else if(c.getPosition() == RIGHT){
                this.emplacement[side][2].add(c);
            }
            c.effetRevele(this);
       }
        for(AbstractCard card: this.getBoard(side)){
            if(card.getEffet().equals("Continu")){
                card.effetContinu(this);
            }
        }
    }

    @Override
    public boolean tryPlay(int side, AbstractCard card, Position p) { // A revoir 
        switch(p){
            case LEFT :
                if(this.emplacement[side][0].size() >= 4){
                    return false;
                }
                if(this.emplacement[side][0].size() < 4 && card.getCout() <= energy[side]){
                    card.setPosition(p);
                    this.cout_prep[side][0].add(card);
                    this.energy[side] = this.energy[side]-card.getCout();
                    this.mains[side].remove(card);
                    return true;
                }
            
            case MIDDLE :
                if(this.emplacement[side][1].size() >= 4){
                    return false;
                }
                if(this.emplacement[side][1].size() < 4 && card.getCout() <= energy[side]){
                    card.setPosition(p);
                    this.cout_prep[side][1].add(card);
                    this.energy[side] = this.energy[side]-card.getCout();
                    this.mains[side].remove(card);
                    return true;
                }
            
            case RIGHT :
                if(this.emplacement[side][2].size() >= 4){
                    return false;
                }
                if(this.emplacement[side][2].size() < 4 && card.getCout()<= energy[side]){
                    card.setPosition(p);
                    this.cout_prep[side][2].add(card);
                    this.energy[side] = this.energy[side]-card.getCout();
                    this.mains[side].remove(card);
                    return true;
                }
            
        }
        return false;
    }

    @Override
    public int getWinner() {
        int n0=0; int n1=0;
        for(Position p: Position.values()){
            if(this.getScore(0, p) > this.getScore(1, p)){
                n0++;
            }
            else{
                n1++;
            }
        }
        if(n0 > n1){
            return 0;
        }
        else if(n0 < n1){ 
            return 1;
        }
        return -1;   // si il y a égalité
    }
    
    
    @Override
    public void new_decks(){
        LinkedList<AbstractCard> n0=Factory.deckBase();
        LinkedList<AbstractCard> n1=Factory.deckBase();
        
        LinkedList<AbstractCard> s0=new LinkedList();
        LinkedList<AbstractCard> s1=new LinkedList();
        
        for(int i=0; i<12; i++){
            s0.add(n0.removeFirst());
            s1.add(n1.removeFirst());
        }
        this.setDeck(0,s0);
        this.setDeck(1,s1);
    }
    
    @Override
    public void pioche(){ // pioche une carte dans le deck et place la carte dans la main
        this.mains[0].add(this.decks[0].removeFirst());
        this.mains[1].add(this.decks[1].removeFirst());
    }
    @Override
    public void setTurn() {
        this.turn++;
    }
    
    @Override
    public void setTurn(int t){
        this.turn=t;
    }

    @Override
    public void setEnergy() {
        this.energy[0]=this.turn;
        this.energy[1]=this.turn;
    }
    @Override
    public void startTurn(){
        this.setEnergy();
        if(this.mains[0].isEmpty() && this.mains[1].isEmpty()){
            for(int i=0; i<3; i++){
                this.pioche();
            }
        }
        else{
            this.pioche();
        }
        
    }

    

    @Override
    public void clearPlay(int side, Position pos) {
        switch(pos){
            case LEFT:
                this.cout_prep[side][0].clear();
            case MIDDLE:
                this.cout_prep[side][1].clear();
            case RIGHT:
                this.cout_prep[side][2].clear();
        }
    }

    @Override
    public void setPlay(int side, LinkedList<AbstractCard> myPlay) {
         for(AbstractCard c:myPlay){
            if(c.getPosition() == LEFT){
                this.cout_prep[side][0].add(c);
            }
            else if(c.getPosition() == MIDDLE){
                this.cout_prep[side][1].add(c);
            }
            else if(c.getPosition() == RIGHT){
                this.cout_prep[side][2].add(c);
            }
       }
    }
}

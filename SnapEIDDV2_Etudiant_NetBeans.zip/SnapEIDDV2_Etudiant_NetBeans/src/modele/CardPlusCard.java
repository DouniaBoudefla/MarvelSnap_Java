/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author douni
 */
public class CardPlusCard extends Card{   // Ajoute une carte Spécial à votre main.
    
    public CardPlusCard(int val, int cout, String nom,String effet) { 
        super(val, cout, nom,effet);
    }
    
    
    @Override
    public void effetRevele(AbstractGame g){
        if(g.getPlay(0).contains(this)){
            AbstractCard c=new Card(this.getValeur()*2,this.getCout()*2,"Special","");
            g.getHand(0).add(c);
            System.out.println("UNE CARTE SPECIAL A ETE AJOUTE AU JOUEUR "+g.getName(0));
        }
        if(g.getPlay(1).contains(this)){
            AbstractCard c=new Card(this.getValeur()*2,this.getCout()*2,"Special","");
            g.getHand(1).add(c);
            System.out.println("UNE CARTE SPECIAL A ETE AJOUTE AU JOUEUR "+g.getName(1));
        }
    }
}

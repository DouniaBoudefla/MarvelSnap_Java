/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

import static modele.Position.LEFT;
import static modele.Position.MIDDLE;
import static modele.Position.RIGHT;

/**
 *
 * @author douni
 */
public class CardDestroyPlusDeux extends Card{ // Détruit toutes les cartes sur le même emplacement. Score +2 pour chaque carte détruite.
    
    public CardDestroyPlusDeux(int val, int cout, String nom,String effet) {
        super(val, cout, nom,effet);
    }
    
    @Override
    public void effetRevele(AbstractGame g){
        for(int side=0;side<2;side++){
            if(this.getPosition() == LEFT){
                int score=0;
                for(AbstractCard c : g.getBoard(side, Position.LEFT)){
                    score=score+2+c.getValeur();
                    c.setPosition(null);
                }
                g.setScore(side, LEFT, score);
                g.getBoard(side, LEFT).clear();
                System.out.println("UNE CARTE DESTROY A ETE JOUE PAR LE JOUEUR "+g.getName(side)+"\n");
            }
            if(this.getPosition() == MIDDLE){
                int score=0;
                for(AbstractCard c : g.getBoard(side, Position.MIDDLE)){
                    score=score+2+c.getValeur();
                    c.setPosition(null);
                }
                g.setScore(side, MIDDLE, score);
                g.getBoard(side, MIDDLE).clear();
                System.out.println("UNE CARTE DESTROY A ETE JOUE PAR LE JOUEUR "+g.getName(side)+"\n");
            }
            if(this.getPosition() == RIGHT){
                int score=0;
                for(AbstractCard c : g.getBoard(side, Position.RIGHT)){
                    score=score+2+c.getValeur();
                    c.setPosition(null);
                }
                g.setScore(side, RIGHT, score);
                g.getBoard(side, RIGHT).clear();
                System.out.println("UNE CARTE DESTROY A ETE JOUE PAR LE JOUEUR "+g.getName(side)+"\n");
            }
        }
        
    }
    
}

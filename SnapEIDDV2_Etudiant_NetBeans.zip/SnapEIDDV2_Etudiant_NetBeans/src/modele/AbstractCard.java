/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modele;

import java.io.Serializable;

/**
 * Une classe abstraite pour modéliser les cartes de jeu.
 * @author pierrecharbit
 */
public abstract class AbstractCard implements Serializable {

	
	
	/**
	 * le nom de la carte
	 * @return 
	 */
	public abstract String getNom();
	
		/**
	 * la valeur de la carte.
	 * @return 
	 */
	public abstract int getValeur();
      
	
	/**
	 * retourne le cout de pose d'une carte
	 * @return un entier 
	 */
	public abstract int getCout();

	/**
	 * le texte qui decrit les pouvoirs eventuels de la carte.
	 * @return 
	 */
	public abstract String getDescription();

	/**
	 * la position actuelle de la carte si elle est posée ou en préparation.
	 * @return une valeur du type enum {@link modele.Position} si la carte est posée ou en train d'etre posée, et null sinon
	 */
	public abstract Position getPosition();

	/**
	 * effet à appliquer lorsque la carte est révélée.
	 * @param g la partie en cours
	 */
	public void effetRevele(AbstractGame g){}
        
        /**
         * effet à appliquer en tant que la carte est presente sur le plateau
         * @param g 
         */
        public void effetContinu(AbstractGame g){}
	
	//public abstract void setSide(int i);
        /**
         * un setter pour modifier la position d'une carte
         * @param p 
         */
	public abstract void setPosition(Position p);
        
        @Override
        public abstract String toString();

        /**
         * un getter pour l'effet de la carte
     * @return effet de la carte
         */
	public abstract String getEffet();
	


}

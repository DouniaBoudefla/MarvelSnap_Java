/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author douni
 */
public class CardPlusUnAdv extends Card {  // Pour chaque carte adverse sur cet emplacement, score +1 
    
    public CardPlusUnAdv(int val, int cout, String nom,String effet) {
        super(val, cout, nom,effet);
    }
    
    @Override
    public void effetContinu(AbstractGame g){
        for(int side=0;side<2;side++){
            if(this.getPosition() != null && g.getBoard(side).contains(this)){
                g.setScore(side, this.getPosition(),g.getBoard(1-side, this.getPosition()).size());
                System.out.println("LE JOUEUR "+g.getName(side)+ " A TOUJOURS UNE CARTE A EFFET CONTINU SUR LE PLATEAU\n");
            }
        }
    }
    
}

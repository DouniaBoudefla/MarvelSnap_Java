
import controleur.AbstractController;
import controleur.Controller;
import controleur.ControllerG;
import java.io.IOException;
import vue.AbstractUI;
import vue.UITerminal;
import java.util.Scanner;
import network.ExchangeConnector;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 * La classe contenant le main.
 * @author pierrecharbit
 */
public class SnapEIDD {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {

           /* AbstractController c=new Controller();
            c.userinterface.displayIntro();
            c.endGame();*/
          
           ExchangeConnector connector=new ExchangeConnector();
           try{
            connector.initConnect();
           Scanner clavier =new Scanner(System.in);
           AbstractController c=new ControllerG();
           AbstractController c1=new Controller();
            c.setupGame();
            
           System.out.println("Quelle interface voulez vous utiliser? Graphique ou terminal");
           String rep = clavier.nextLine();
           String repOpponent = connector.exchangeObj(rep);
	   if(rep.equalsIgnoreCase("Graphique") && repOpponent.equalsIgnoreCase("Graphique")){
           
               c.startGame();
           }
           else if(rep.equalsIgnoreCase("Terminal")&& repOpponent.equalsIgnoreCase("Terminal")){
               c1.userinterface.displayIntro();
                c1.endGame();
               
           }
           else{
               
               c.startGame();
           }
           }
            catch(IOException e){
            System.out.println("ERREUR");
            

        }
           		
           
            
            
            
              



         
		
	}
        
        
	
}


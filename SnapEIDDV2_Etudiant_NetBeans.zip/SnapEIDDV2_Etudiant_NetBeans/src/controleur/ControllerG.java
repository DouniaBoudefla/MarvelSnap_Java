
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controleur;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;
import modele.AbstractCard;
import modele.Game;
import modele.Position;
import static modele.Position.LEFT;
import static modele.Position.MIDDLE;
import static modele.Position.RIGHT;
import network.ExchangeConnector;
import vue.AbstractUI;
import vue.UIGraphic;
import vue.UITerminal;

/**
 *
 * @author afdol
 */
public class ControllerG extends AbstractController{
    public ControllerG(){
        this.connector=new ExchangeConnector();
        this.game=new Game();
        this.userinterface=new UIGraphic(this);
    }

    @Override
    public boolean setupGame() {
         try{
            this.connector.initConnect();


            Scanner clavier =new Scanner(System.in);
            System.out.println("Quel est votre nom de Joueur? ");
            String monNom = clavier.nextLine();
            String nomOpponent = connector.exchangeObj(monNom);
            this.game.setName(this.connector.side, monNom);
            this.game.setName(1-this.connector.side, nomOpponent);
            System.out.println("C'est parti, on joue contre "+ nomOpponent);

            //this.userinterface.displayIntro();
            //this.userinterface.displayMenu();

            this.game.new_decks();
            this.game.setTurn(-1);
            this.game.setEnergy();


            return true;
        }

        catch(IOException e){
            System.out.println("ERREUR");
            return false;

        }
    }

    @Override
    public void startGame() {
        // this.setupGame();
      this.userinterface.launchGame(this.game);
      this.userinterface.updateGameWindow();
      this.endTurn();
     
      




    }

    @Override
    public void endTurn() {
        if(this.game.getTurn()<=6){
        int s=connector.side;
        LinkedList<AbstractCard> Moi=this.game.getPlay(s);
        LinkedList<AbstractCard> Adv=this.connector.exchangeObj(Moi);
        this.game.setPlay(1-s,Adv);
        this.game.setBoard(s,Moi);
        this.game.setBoard(1-s,Adv);
        
        for(Position p: Position.values()){
            this.game.getPlay(s, p).clear();
            this.game.getPlay(1-s,p).clear();
        }
        /*for(int side=0;side<2;side++){
            for(Position p: Position.values()){
                for(AbstractCard c: this.game.getPlay(side)){
                    if(c.getPosition() == p){
                        this.game.getBoard(side,p).add(c);
                    }
                }
                this.game.getPlay(side, p).clear();
            }


        }*/
        this.game.setTurn();
        this.game.setEnergy();
        this.userinterface.updateGameWindow();
       
        this.game.startTurn();
        }
        else{
            this.endGame();
            
        }
    }
    @Override
    public void endGame() {
      
         this.userinterface.endGame();
       

    }

}
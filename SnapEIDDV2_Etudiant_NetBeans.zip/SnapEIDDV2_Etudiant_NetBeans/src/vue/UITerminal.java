
package vue;

import controleur.AbstractController;
import java.util.LinkedList;
import java.util.Scanner;

import modele.AbstractCard;
import modele.AbstractGame;
import modele.Position;
import static modele.Position.LEFT;
import static modele.Position.MIDDLE;
import static modele.Position.RIGHT;

/**
 * Une classe qui implémente l'interface {@link AbstractUI} dans le terminal
 *
 * @author pierrecharbit
 */
public class UITerminal extends AbstractUI {

	Scanner sc = new Scanner(System.in);

	public UITerminal(AbstractController gc) {
		this.controller = gc;
	}

	@Override
	public void endGame() {
		if (game.getWinner() == controller.getIndexPlayer()) { //!!!!!!
			System.out.println("Vous avez gagne !!!");
		}
                else if(game.getWinner() == -1){
                    System.out.println("Il n'y a pas de gagnant !!");
                }
		else {
			System.out.println("LOOOOOOOOSER !! ");
		}
		waitForInput();
	}

	@Override
	public void displayIntro() {
		System.out.println("------------------------------ BIENVENUE DANS LE SUPER JEU ----------------------------------");
		this.displayLoginMenu();
	}

	@Override
	public void displayLoginMenu() {
		controller.startMainMenu();
	}

	@Override
	public void displayMenu() {
		while (!controller.setupGame()) {
		}
		System.out.println("stargame");
		controller.startGame();

	}

	@Override
	public void launchGame(AbstractGame g) {
		this.game = g; //// !!!!!!!!!!
		int side = controller.getIndexPlayer();
		System.out.println("------  Nouvelle Partie    ----------");
		System.out.println("Adversaire : " + game.getName(1 - side));
		this.game.startTurn();//!!!!!!
		launchTurn();
	}

	/**
	 * reaffiche le plateau et lance la méthode de saisie du coup d'un joueur.
	 */
	@Override
	public void launchTurn() {
		clearScreen();
		System.out.println("------------------------------ VOUS ALLEZ JOUER SUR CE PLATEAU ------------------------------");
		printBoard();
		getPlay();
		controller.endTurn();
	}

	/**
	 * reaffiche le plateau.
	 */
	@Override
	public void updateGameWindow() {
		clearScreen();
		printBoard();
	}

	public void getPlay() {
		int side_me = controller.getIndexPlayer();
		this.clearScreen();
		System.out.println("\n\n------------------------------ PLATEAU ACTUELLEMENT ------------------------------");
		this.printBoard();
		boolean ok;
		while (true) {
			ok=false;
			System.out.println("\n\nVous avez " + game.getEnergy(side_me) + " energies");
			System.out.println("\n\nVoici votre main");
			LinkedList<AbstractCard> hand = game.getHand(side_me);
			for (int i = 0; i < hand.size(); i++) {
				System.out.println(i + ")" + hand.get(i));
			}
			int ch = -2;
			while(ch < 0 || ch >= hand.size()){
				System.out.print("Quelle carte voulez vous poser? (-1 pour passer votre tour) : ");
				ch = sc.nextInt();
				if(ch == -1){
					break;
				}
			}
			//!!!!
			if (ch == -1) {
				break;
			}
			if (ch >= 0 && ch < hand.size()) {
				this.clearScreen();
				System.out.println("\n\n------------------------------ PLATEAU ACTUELLEMENT ------------------------------");
				this.printBoard();
				System.out.println("Carte choisie : " + hand.get(ch));
				int sp = -1;
				while(sp > 3 || sp < 1){
					System.out.print("Sur quel emplacement voulez vous la poser (1-2-3?)   :");
					sp=sc.nextInt();
				}

				Position p=null;
				switch (sp) {
					case 1:
						p=LEFT;
						break;
					case 2:
						p=MIDDLE;
						break;
					case 3:
						p=RIGHT;
						break;
					default:
						break;
				}

				ok = game.tryPlay(side_me, hand.get(ch), p);
			}

			this.clearScreen();
			System.out.println("\n\n------------------------------ PLATEAU DE JEU APRES VOTRE CHOIX ------------------------------");
			this.printBoard();
			if (!ok) {
				System.out.println("Tentative Non Valide");
			}
			
			System.out.print("\n Voulez vous vous arreter la et valider votre coup?");
			String rep = sc.next();
			if (rep.toLowerCase().equals("oui")) {
				break;
			}

		}
                System.out.println("\n\nEN ATTENTE DU JOUEUR ADVERSE\n");
	}

	private void waitForInput() {
		System.out.println("Appuyez sur n'importe quel touche puis entree pour recommencer une partie");
		sc.next();
	}

	private void printBoard() {
		int side_me = controller.getIndexPlayer();
		System.out.println("\t---------------------------BOARD-------------------------- ");
		for (int i = 0; i < 4; i++) {
			for (Position pos : Position.values()) {
				
					LinkedList<AbstractCard> l=new LinkedList();
					l.addAll(game.getBoard(1 - side_me, pos)); ////ERREUR !!!!!					//System.out.println("getBoard(): "+l+pos);
					AbstractCard c; 
					if (i < l.size()) {
						c = l.get(i);
						System.out.print("\t  /" + c.getValeur() + "/");
					}
					else {
						System.out.print("\t  //");
					}
					System.out.print("\t\t");
					l.clear();
				

			}
			System.out.println("");
		}
                
              

		System.out.println("\t---------------------------------------------------------- ");

		System.out.println("");
		/*affichage des score de lui sur les terrains*/
		for (Position pos : Position.values()) {
			System.out.print("\t  " + game.getScore(1-side_me, pos) + "\t\t"); //!!!!!!
		}
		System.out.println("");
		/*affichage du nom du terrain*/

		for (Position pos : Position.values()) {
			System.out.print("\t\t\t");

//			System.out.print("\t" +game.getNameEmplacement(pos) + "\t\t");
		}
		System.out.println("");
		/*affichage des score de moi sur les terrains*/
		for (Position pos : Position.values()) {
			System.out.print("\t  " + game.getScore(side_me, pos) + "\t\t"); //!!!!!
                       
		}
         
		System.out.println("\n");
		System.out.println("\t---------------------------------------------------------- ");
     
		for (int i = 0; i < 4; i++) {
			for (Position pos : Position.values()) {
                      
				LinkedList<AbstractCard> l = new LinkedList();
				l.addAll(game.getBoard(side_me, pos));

				AbstractCard c;
				if (i < l.size()) {
					c = l.get(i);
					System.out.print("\t  /" + c.getValeur() + "/");
				}
				else {
					System.out.print("\t  //");
				}
				System.out.print("\t\t");
				l.clear();
			}

			System.out.println("");
		}
		System.out.println("\t---------------------------BOARD-------------------------- ");
	}

	private void clearScreen() {
		System.out.print("\033[H\033[2J");
		System.out.flush();
	}

}
